# Portfolio Atividade 1 - HTML

A Pen created on CodePen.

Original URL: [https://codepen.io/Gabriel-Isac-M-Tomaz/pen/QwWLJde](https://codepen.io/Gabriel-Isac-M-Tomaz/pen/QwWLJde).

